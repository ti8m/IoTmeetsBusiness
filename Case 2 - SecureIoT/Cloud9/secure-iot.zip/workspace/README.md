
Thesis "IoT meets Business"
